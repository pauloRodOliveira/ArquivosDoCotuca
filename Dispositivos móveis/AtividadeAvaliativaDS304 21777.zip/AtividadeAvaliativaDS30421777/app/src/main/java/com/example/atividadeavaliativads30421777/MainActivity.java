package com.example.atividadeavaliativads30421777;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.atividadeavaliativads30421777.classes.Aluno;
import com.example.atividadeavaliativads30421777.classes.HttpsTrustManager;
import com.example.atividadeavaliativads30421777.classes.UsuarioWS;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView listaAlunos;
    private Button btnAbrirLista;
    private ArrayAdapter<String> listaNomes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Botao que recebe abre a lista de alunos
        btnAbrirLista = findViewById(R.id.btnAbrirLista);

        //List view com os alunos
        listaAlunos = findViewById(R.id.listaAlunos);

        btnAbrirLista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AsyncTask.execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            HttpsTrustManager.allowAllSSL();
                            Aluno[] aluno = (Aluno[]) UsuarioWS.getObjeto(Aluno[].class, "https://ds302.herokuapp.com/url");
                            ArrayList<String> alunos = new ArrayList<>();
                            for(int pos = 0; pos <= aluno.length-1; pos++){
                                alunos.add(aluno[pos].toString());
                            }
                            listaNomes = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, alunos);

                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    listaAlunos.setAdapter(listaNomes);
                                }
                            });
                        } catch (Exception e) {
                            System.err.println(e.getMessage());
                        }
                    }
                });
            }
        });

        listaAlunos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String nome = (String) listaAlunos.getItemAtPosition(i);

                Intent intent = new Intent(getApplicationContext(), NomeCompleto.class);
                intent.putExtra("nome", nome);
                startActivity(intent);
            }
        });
    }
}