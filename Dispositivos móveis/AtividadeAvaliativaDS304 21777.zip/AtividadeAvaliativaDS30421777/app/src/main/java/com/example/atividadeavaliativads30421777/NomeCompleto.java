package com.example.atividadeavaliativads30421777;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.atividadeavaliativads30421777.classes.Aluno;
import com.example.atividadeavaliativads30421777.classes.HttpsTrustManager;
import com.example.atividadeavaliativads30421777.classes.UsuarioWS;

import java.util.ArrayList;

public class NomeCompleto extends AppCompatActivity {
    private String nome;
    private TextView txtNome;
    private Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nome_completo);

        //Recuperando os dados da outra intent
        Bundle bundle = getIntent().getExtras();
        nome = (String) bundle.get("nome");

        txtNome = findViewById(R.id.txtNome);
        btnVoltar = findViewById(R.id.btnVoltar);

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpsTrustManager.allowAllSSL();
                    Aluno[] aluno = (Aluno[]) UsuarioWS.getObjeto(Aluno[].class, "https://ds302.herokuapp.com/url?id=" + nome);
                    ArrayList<String> alunos = new ArrayList<>();
                    for(int pos = 0; pos <= aluno.length-1; pos++){
                        alunos.add(aluno[pos].toString());
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            txtNome.setText((CharSequence) alunos.get(0).toString());
                        }
                    });
                } catch (Exception e) {
                    System.err.println(e.getMessage());
                }
            }
        });
    }
}