package com.example.atividadeavaliativads30421777.classes;

public class Aluno {

    private String firstname;
    private String lastname;
    private int id;

    public String getFirstname() {
        return this.firstname;
    }

    public void setfirstname(String firstname) throws Exception {
        if (firstname == null || firstname.length() == 0)
            throw new Exception("firstname inválido");

        this.firstname = firstname;
    }

    public void setId(int id) throws Exception {
        if (id < 0)
            throw new Exception("id inválido");
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setLastname(String lastname) throws Exception {
        if (lastname == null ||lastname.length() == 0)
            throw new Exception("lastname inválido");
        this.lastname = lastname;
    }

    public String getLastname() {
        return lastname;
    }

    public Aluno(String firstname
    ) throws Exception {
        this.setfirstname(firstname);
    }

    public Aluno(String firstname,
                 String lastname
    ) throws Exception {
        this.setfirstname(firstname);
        this.setLastname(lastname);
    }

    public Aluno() {
    }

    public String toString() {
        String nome = "";

        if(lastname == null) nome += getFirstname();
        else nome += getFirstname() + " " + getLastname();

        return nome;
    }

    public boolean equals(Object obj) {
        if (this == obj)
            return true;

        if (obj == null)
            return false;

        if (!(obj instanceof Aluno))
            return false;

        Aluno aluno = (Aluno) obj;

        if (!this.firstname.equals(aluno.getFirstname()))
            return false;

        if(this.getId() != aluno.getId())
            return false;

        return true;
    }

    public int hashCode() {
        int ret = 1;

        ret = 2 * ret + this.firstname.hashCode();

        return ret;
    }

    public Aluno(Aluno obj) throws Exception {
        if (obj == null)
            throw new Exception("Modelo inexistente");

        this.firstname = obj.firstname;
        this.id = obj.getId();
        this.lastname = obj.getLastname();
    }

    public Object clone() {
        Aluno ret = null;

        try {
            ret = new Aluno(this);
        } catch (Exception erro) {
        }

        return ret;
    }
}
